"""
Training script for the medical image classifier.
"""

import os

import joblib
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.svm import SVC

from pipeline import (
    DATASET_DIR,
    MODEL_PATH,
    OUTPUT_DIR,
    choose_pca_components,
    ensure_dataset_exists,
    prepare_split,
    plot_class_distribution,
    plot_confusion,
    plot_learning_curve,
)


def train_and_evaluate():
    ensure_dataset_exists(DATASET_DIR)

    X_train, y_train = prepare_split("train")
    X_test, y_test = prepare_split("test")

    if len(y_train) == 0 or len(X_train) == 0:
        raise ValueError("Training data is empty after filtering unreadable images.")

    if len(y_test) == 0 or len(X_test) == 0:
        print("[WARN] Test data empty after filtering; evaluation will be skipped.")

    # Encoding, scaling, PCA
    le = LabelEncoder()
    y_train_enc = le.fit_transform(y_train)
    y_test_enc = le.transform(y_test) if len(y_test) else []

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test) if len(X_test) else None

    pca_components = choose_pca_components(X_train_scaled)
    pca = PCA(n_components=pca_components)
    X_train_pca = pca.fit_transform(X_train_scaled)
    X_test_pca = pca.transform(X_test_scaled) if X_test_scaled is not None else None

    # Train classifiers
    svm = SVC(kernel="rbf", class_weight="balanced")
    knn = KNeighborsClassifier(n_neighbors=5)
    rf = RandomForestClassifier(
        n_estimators=150,
        class_weight="balanced",
        random_state=42,
    )

    voting = VotingClassifier(
        estimators=[("svm", svm), ("knn", knn), ("rf", rf)],
        voting="hard",
    )

    print("\n=== Training Models ===")
    voting.fit(X_train_pca, y_train_enc)

    # Save bundle
    bundle = {
        "scaler": scaler,
        "pca": pca,
        "encoder": le,
        "model": voting,
    }
    joblib.dump(bundle, MODEL_PATH)
    print(f"\n[OK] Model saved to {MODEL_PATH}")

    # Training set class distribution plot
    plot_class_distribution(
        y_train, os.path.join(OUTPUT_DIR, "train_class_distribution.png")
    )

    # Learning curve on training data (with cross-validation)
    plot_learning_curve(
        voting, X_train_pca, y_train_enc, os.path.join(OUTPUT_DIR, "learning_curve.png")
    )

    # Evaluation
    if X_test_pca is not None and len(y_test_enc):
        print("\n=== Evaluation ===")
        y_pred = voting.predict(X_test_pca)

        print("Accuracy:", accuracy_score(y_test_enc, y_pred))

        report = classification_report(y_test_enc, y_pred, target_names=le.classes_)
        print(report)

        with open(os.path.join(OUTPUT_DIR, "classification_report.txt"), "w") as f:
            f.write(report)

        cm = confusion_matrix(y_test_enc, y_pred)
        plot_confusion(cm, le.classes_, os.path.join(OUTPUT_DIR, "confusion_matrix.png"))
    else:
        print("[WARN] Skipped evaluation because no test data was available.")

    return bundle


if __name__ == "__main__":
    train_and_evaluate()
