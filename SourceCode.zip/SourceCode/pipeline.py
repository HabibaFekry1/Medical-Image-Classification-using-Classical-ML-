
import os
from collections import Counter
from pathlib import Path
from typing import List, Sequence, Tuple

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from skimage import color, io, transform
from skimage.feature import hog
from sklearn.model_selection import learning_curve
from tqdm import tqdm

# CONFIG

DATASET_DIR = "medical_Classifier_Dataset"
MODEL_PATH = "model/hbms_classifiers.joblib"
OUTPUT_DIR = "outputs"

IMAGE_SIZE = (96, 96)
BATCH_SIZE = 200

os.makedirs("model", exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

HOG_PARAMS = dict(
    orientations=9,
    pixels_per_cell=(16, 16),
    cells_per_block=(2, 2),
    block_norm="L2-Hys",
)


def ensure_dataset_exists(dataset_dir: str = DATASET_DIR) -> None:
    """Fail fast if required dataset folders are missing."""
    required = [Path(dataset_dir) / "train", Path(dataset_dir) / "test"]
    missing = [str(p) for p in required if not p.is_dir()]
    if missing:
        raise FileNotFoundError(f"Dataset split folders not found: {', '.join(missing)}")


def load_image_paths(path: str) -> Tuple[List[str], List[str]]:
    """Collect image file paths and labels; skip broken images with warnings."""
    image_paths, labels = [], []

    if not os.path.isdir(path):
        raise FileNotFoundError(f"Dataset split missing: {path}")

    for cls in sorted(os.listdir(path)):
        cls_path = os.path.join(path, cls)
        if not os.path.isdir(cls_path):
            continue

        for f in os.listdir(cls_path):
            if f.lower().endswith((".png", ".jpg", ".jpeg")):
                img_path = os.path.join(cls_path, f)
                try:
                    _ = io.imread(img_path)  # test read
                    image_paths.append(img_path)
                    labels.append(cls)
                except Exception as exc:
                    print(f"[WARN] skipping unreadable file {img_path}: {exc}")

        print(f"[OK] {cls}: {labels.count(cls)} valid images")

    return image_paths, labels


def extract_features(img: np.ndarray) -> np.ndarray:
    """Resize, handle RGBA safely, convert to grayscale, and compute HOG features."""
    img = transform.resize(img, IMAGE_SIZE)
    img = img.astype(np.float32)

    if img.ndim == 3 and img.shape[2] == 4:
        img = img[:, :, :3]  # drop alpha channel

    gray = color.rgb2gray(img) if img.ndim == 3 else img
    features = hog(gray, **HOG_PARAMS)
    return features


def extract_features_in_batches(
    image_paths: Sequence[str], labels: Sequence[str]
) -> Tuple[np.ndarray, List[str]]:
    """Compute features in batches; drop labels for unreadable images."""
    features, kept_labels = [], []

    for i in tqdm(range(0, len(image_paths), BATCH_SIZE)):
        batch = list(zip(image_paths[i : i + BATCH_SIZE], labels[i : i + BATCH_SIZE]))

        for path, label in batch:
            try:
                img = io.imread(path)
                feat = extract_features(img)
                features.append(feat)
                kept_labels.append(label)
            except Exception as exc:
                print(f"[WARN] skipping during feature extraction {path}: {exc}")

    return np.array(features), kept_labels


def prepare_split(split_name: str):
    """Load and featurize one split."""
    split_path = os.path.join(DATASET_DIR, split_name)
    print(f"\n=== Loading {split_name.title()} Data ===")
    paths, labels = load_image_paths(split_path)

    print(f"\n=== Extracting {split_name.title()} Features ===")
    features, kept_labels = extract_features_in_batches(paths, labels)
    return features, kept_labels


def choose_pca_components(X: np.ndarray, cap: int = 120) -> int:
    """Choose a PCA component count that is valid for the dataset size."""
    max_valid = min(X.shape[0] - 1, X.shape[1])
    if max_valid < 1:
        raise ValueError("Not enough data to compute PCA. Check your dataset.")
    return min(cap, max_valid)


def plot_class_distribution(labels: Sequence[str], output_path: str):
    """Save a bar plot of class counts for the training set."""
    counts = Counter(labels)
    classes = sorted(counts.keys())
    values = [counts[c] for c in classes]

    plt.figure(figsize=(6, 4))
    sns.barplot(x=classes, y=values, palette="Blues_d")
    plt.title("Training Class Distribution")
    plt.ylabel("Count")
    plt.xlabel("Class")
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()


def plot_confusion(cm: np.ndarray, class_names: Sequence[str], output_path: str):
    """Save a heatmap of the confusion matrix."""
    plt.figure(figsize=(6, 5))
    sns.heatmap(
        cm,
        annot=True,
        fmt="d",
        cmap="Blues",
        xticklabels=class_names,
        yticklabels=class_names,
    )
    plt.title("Confusion Matrix")
    plt.xlabel("Predicted")
    plt.ylabel("True")
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()


def plot_learning_curve(estimator, X: np.ndarray, y: np.ndarray, output_path: str):
    """Compute and save a learning curve plot."""
    train_sizes, train_scores, val_scores = learning_curve(
        estimator,
        X,
        y,
        cv=3,
        train_sizes=np.linspace(0.2, 1.0, 5),
        n_jobs=-1,
        shuffle=True,
        random_state=42,
    )
    train_mean = np.mean(train_scores, axis=1)
    train_std = np.std(train_scores, axis=1)
    val_mean = np.mean(val_scores, axis=1)
    val_std = np.std(val_scores, axis=1)

    plt.figure(figsize=(6, 4))
    plt.plot(train_sizes, train_mean, "o-", label="Training score")
    plt.plot(train_sizes, val_mean, "o-", label="Cross-validation score")
    plt.fill_between(train_sizes, train_mean - train_std, train_mean + train_std, alpha=0.2)
    plt.fill_between(train_sizes, val_mean - val_std, val_mean + val_std, alpha=0.2)
    plt.title("Learning Curve (Accuracy)")
    plt.xlabel("Training samples")
    plt.ylabel("Accuracy")
    plt.legend(loc="best")
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
