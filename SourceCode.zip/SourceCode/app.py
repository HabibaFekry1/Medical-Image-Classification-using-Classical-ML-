

import os
import tkinter as tk
from tkinter import filedialog, messagebox

import joblib
import numpy as np
from PIL import Image, ImageTk

from pipeline import MODEL_PATH, extract_features


def load_bundle(path: str = MODEL_PATH):
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Saved model not found at {path}. Run `python train.py` first."
        )
    return joblib.load(path)


def build_predict_fn(bundle):
    scaler = bundle["scaler"]
    pca = bundle["pca"]
    encoder = bundle["encoder"]
    model = bundle["model"]

    def predict_path(image_path: str) -> str:
        img = Image.open(image_path).convert("RGB")
        arr = np.array(img)
        feat = extract_features(arr)
        feat = scaler.transform([feat])
        feat = pca.transform(feat)
        pred = model.predict(feat)[0]
        return encoder.inverse_transform([pred])[0]

    return predict_path


class App(tk.Tk):
    def __init__(self, predict_fn):
        super().__init__()
        self.title("Medical Image Classifier")
        self.geometry("520x600")
        self.predict_fn = predict_fn
        self.current_image = None
        self._build_ui()

    def _build_ui(self):
        tk.Label(self, text="Medical Image Classifier", font=("Segoe UI", 16, "bold")).pack(
            pady=(12, 6)
        )
        tk.Label(
            self,
            text="Select a PNG/JPG medical image to predict (CT/X-ray).",
            font=("Segoe UI", 10),
        ).pack(pady=(0, 12))

        btn = tk.Button(self, text="Select Image", command=self.select_image, width=20)
        btn.pack(pady=(0, 10))

        self.preview = tk.Label(self)
        self.preview.pack(pady=8)

        self.path_label = tk.Label(self, text="", wraplength=480, fg="#444")
        self.path_label.pack(pady=(0, 8))

        self.result_var = tk.StringVar(value="Prediction: —")
        tk.Label(self, textvariable=self.result_var, font=("Segoe UI", 12, "bold")).pack(
            pady=6
        )

    def select_image(self):
        path = filedialog.askopenfilename(
            filetypes=[("Image files", "*.png *.jpg *.jpeg"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            pred = self.predict_fn(path)
            self.result_var.set(f"Prediction: {pred}")
            self.path_label.config(text=path)
            self._update_preview(path)
        except Exception as exc:
            messagebox.showerror("Error", f"Failed to predict: {exc}")

    def _update_preview(self, path: str):
        img = Image.open(path).convert("RGB")
        img.thumbnail((480, 360))
        self.current_image = ImageTk.PhotoImage(img)
        self.preview.config(image=self.current_image)


def main():
    bundle = load_bundle(MODEL_PATH)
    predict_fn = build_predict_fn(bundle)
    app = App(predict_fn)
    app.mainloop()


if __name__ == "__main__":
    main()
